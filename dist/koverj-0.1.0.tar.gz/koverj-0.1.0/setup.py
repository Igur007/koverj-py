# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['koverj',
 'koverj.agent',
 'koverj.agent.selenium',
 'koverj.common',
 'koverj.common.client',
 'koverj.common.config',
 'koverj.common.model',
 'koverj.common.plugin',
 'koverj.common.service']

package_data = \
{'': ['*'],
 'koverj': ['koverj-browser-plugin/.gitignore',
            'koverj-browser-plugin/.gitignore',
            'koverj-browser-plugin/.gitignore',
            'koverj-browser-plugin/.gitignore',
            'koverj-browser-plugin/.gitignore',
            'koverj-browser-plugin/assets/css/*',
            'koverj-browser-plugin/assets/icon.png',
            'koverj-browser-plugin/assets/js/*',
            'koverj-browser-plugin/graph.html',
            'koverj-browser-plugin/graph.html',
            'koverj-browser-plugin/graph.html',
            'koverj-browser-plugin/graph.html',
            'koverj-browser-plugin/graph.html',
            'koverj-browser-plugin/index.html',
            'koverj-browser-plugin/index.html',
            'koverj-browser-plugin/index.html',
            'koverj-browser-plugin/index.html',
            'koverj-browser-plugin/index.html',
            'koverj-browser-plugin/manifest.json',
            'koverj-browser-plugin/manifest.json',
            'koverj-browser-plugin/manifest.json',
            'koverj-browser-plugin/manifest.json',
            'koverj-browser-plugin/manifest.json',
            'koverj-browser-plugin/mock/*',
            'koverj-browser-plugin/options.html',
            'koverj-browser-plugin/options.html',
            'koverj-browser-plugin/options.html',
            'koverj-browser-plugin/options.html',
            'koverj-browser-plugin/options.html',
            'koverj-browser-plugin/plugin/*']}

install_requires = \
['configparser>=5.0.0,<6.0.0',
 'future>=0.18.2,<0.19.0',
 'pytest>=5.4.1,<6.0.0',
 'requests>=2.23.0,<3.0.0',
 'selene>=1.0.2,<2.0.0',
 'selenium==3.141']

setup_kwargs = {
    'name': 'koverj',
    'version': '0.1.0',
    'description': 'Test coverage for selenium based tests',
    'long_description': None,
    'author': 'Ivan Huryn',
    'author_email': 'igur007@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
